<?php
$dbhost='localhost';
$dbname='my_db';
$dbpass='';
$dbusername='root';
$mysqli=mysqli_connect($dbhost,$dbusername,$dbpass,$dbname);
?>