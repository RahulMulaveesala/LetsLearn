<?php
	include("config.php");
?>
<!doctype html>
<html>
<head>
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="bootstrap-3.4.1-dist\css\bootstrap.min.css">	  
 	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
	<nav class="navbar sticky-top navbar-default" style="position:fixed;z-index:100;width: 100%;">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" href="index.html">Home</a>
			</div>
			<ul class="nav navbar-nav">
			<li class="active"><a href="cintro.html">C</a></li>
			<li><a href="intro.html">C++</a></li>
			<li><a href="javaintro.html">Java</a></li>
			</ul>
		</div>
	</nav>
	<?php
		if(isset($_POST['submit'])){
			$name = $_POST['nam'];
			$email = $_POST['ema'];
			$rating = $_POST['rate'];
			if($name != null && $email != null && $rating != null && !empty(trim($name)))
			{
				mysqli_query($mysqli,"INSERT INTO feedback values('$name','$email','$rating',NOW())");
				echo "<div class='container'>
				<div class='alert alert-success alert-dismissible fade in'>
				<a href='index.html' class='close' aria-label='close'>&times;</a>
				Thank you for your feedback.
				</div>
				</div>
				";
			}
			else
			{
				echo "<div class='container'>
				<div class='alert alert-danger alert-dismissible fade in'>
				<a href='feedback.html' class='close' aria-label='close'>&times;</a>
				Failed to Submit, please enter details properly.
				</div>
				</div>
				";
			}
		}  
	?>	
</body>
</html>