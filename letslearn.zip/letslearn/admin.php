
<?php
include("config.php");
$result=mysqli_query($mysqli,"select * from feedback order by date desc");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin Page</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="bootstrap-3.4.1-dist\css\bootstrap.min.css">
</head>
<body>
  <form>
      <!-- <input type="text" name="valueToSearch" placeholder="Value To Search"><br><br>
       <input type="submit" name="search" value="Filter"><br><br>-->
	   <nav class="navbar navbar-default">
		<div class="container-fluid">
			<div class="nav navbar-nav navbar-right">
				<a class="navbar-brand" href="welcome.html">Logout</a>
			</div>
		</div>
	</nav>
	   <div class="container">
	   <br>
	   <br>
		      <h1>Feedback</h1>
		   <table class="table table-striped">
			   <thead>
				  <tr>
					<th>Name</th>
					<th>Email</th>
					<th>Rating</th>
					<th>date</th>
				 </tr>
			    </thead>
                <?php
                  while($row = mysqli_fetch_array($result)){
                       echo '<tr>';
                       echo '<td>'.$row['name'].'</td>';
                       echo '<td>'.$row['email'].'</td>';
                       echo '<td>'.$row['rating'].'</td>';
                       echo '<td>'.$row['date'].'</td>';
                       echo '</tr>';
                  }
                ?>
		    </table>
	   </div>
    </form>
</body>
</html> 